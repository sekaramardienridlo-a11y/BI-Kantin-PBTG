package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;

public class koneksi {
    public static Connection koneksi;

    public static Connection getKoneksi() {
        if (koneksi == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/kantinsekolah";
                String user = "root";
                String pass = ""; // jika pake XAMPP bawaan, password dibiarkan kosong
                
                Class.forName("com.mysql.cj.jdbc.Driver");
                koneksi = DriverManager.getConnection(url, user, pass);
                System.out.println("Koneksi Berhasil!");
            } catch (Exception e) {
                System.out.println("Koneksi Gagal: " + e.getMessage());
            }
        }
        return koneksi;
    }
}